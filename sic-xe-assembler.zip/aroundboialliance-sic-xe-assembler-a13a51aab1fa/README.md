# SIC/XE Assembler

##1. Compile using the given makefile.

If running on Tesla, run `make tesla`.  For everyone else not running an out of date compiler, just run `make`.

##2. Run
Use the following command to run: `./sic-asm <source file>`, where `<source file>` is the path to the file you would like  to assemble.

For example:
~~~
./sic-asm sample/basic.txt
~~~