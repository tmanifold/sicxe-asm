
// exit.h

#ifndef _EXIT_H_
#define _EXIT_H_

#define EXIT_CODE_OK 0
#define EXIT_CODE_INVALID_ARGS 1
#define EXIT_CODE_INVALID_FILE -1

#endif //_EXIT_H_
